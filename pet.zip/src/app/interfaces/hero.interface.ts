export interface Hero {
  id: number;
  name: string;
  origin: string;
  age: number;
}
